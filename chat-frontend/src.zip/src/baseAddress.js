//change before build to prod address
// const base = "http://165.227.185.180";
const base = "http://127.0.0.1:8000";
export default base;
